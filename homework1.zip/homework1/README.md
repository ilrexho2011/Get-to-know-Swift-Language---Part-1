# Get Swifty - Part 1

## Homework 1 `Variables and Constants`

