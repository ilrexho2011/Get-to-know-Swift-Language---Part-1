# Get Swifty - Part 1

## Homework 2 `Collections`

