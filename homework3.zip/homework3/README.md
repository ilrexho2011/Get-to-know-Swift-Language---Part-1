# Get Swifty - Part 1

## Homework 3 `Control Flow`

